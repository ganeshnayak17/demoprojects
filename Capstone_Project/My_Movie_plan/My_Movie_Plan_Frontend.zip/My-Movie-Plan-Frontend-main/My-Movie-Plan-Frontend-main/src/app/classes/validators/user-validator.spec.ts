import { UserValidator } from './user-validator';

describe('UserValidator', () => {
  it('should create an instance', () => {
    expect(new UserValidator()).toBeTruthy();
  });
});
